// ─── Service Worker (minimal) ────────────────────────────────
// Handles extension install and badge updates.

chrome.runtime.onInstalled.addListener(() => {
  console.log("CC Feedback extension installed");
});
