// ─── Popup Settings ──────────────────────────────────────────

const fields = ["serverUrl", "apiToken", "testerName", "projectSlug"];

// Load saved settings
chrome.storage.local.get(
  {
    serverUrl: "http://91.99.211.238:3100",
    apiToken: "",
    testerName: "",
    projectSlug: "",
  },
  (settings) => {
    for (const key of fields) {
      document.getElementById(key).value = settings[key] || "";
    }
  }
);

// Save settings
document.getElementById("save").addEventListener("click", () => {
  const values = {};
  for (const key of fields) {
    values[key] = document.getElementById(key).value.trim();
  }

  chrome.storage.local.set(values, () => {
    const status = document.getElementById("status");
    status.textContent = "✓ Guardado";
    setTimeout(() => (status.textContent = ""), 2000);
  });
});
