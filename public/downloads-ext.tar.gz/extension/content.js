// ─── Command Center Feedback — Content Script ──────────────
// Injects a floating button for voice feedback recording.

(function () {
  "use strict";

  let mediaRecorder = null;
  let audioChunks = [];
  let isRecording = false;
  let currentSessionId = null;
  let pagesVisited = [window.location.href];
  let lastCursorX = 0;
  let lastCursorY = 0;

  // Track cursor position and hovered element
  let lastHoveredElement = null;

  document.addEventListener("mousemove", (e) => {
    lastCursorX = e.clientX;
    lastCursorY = e.clientY;
    lastHoveredElement = e.target;
  });

  // Track page navigation (SPA)
  const pushState = history.pushState;
  history.pushState = function () {
    pushState.apply(this, arguments);
    onNavigate();
  };
  window.addEventListener("popstate", onNavigate);

  function onNavigate() {
    const url = window.location.href;
    if (!pagesVisited.includes(url)) {
      pagesVisited.push(url);
    }
  }

  // ─── DOM Element Capture ────────────────────────────────────

  function getCssSelector(el) {
    if (!el || el === document.body || el === document.documentElement) return "body";
    var parts = [];
    var current = el;
    while (current && current !== document.body) {
      var tag = current.tagName.toLowerCase();
      if (current.id) {
        parts.unshift(tag + "#" + current.id);
        break;
      }
      var classes = current.className && typeof current.className === "string"
        ? "." + current.className.trim().split(/\s+/).slice(0, 3).join(".")
        : "";
      var parent = current.parentElement;
      if (parent) {
        var siblings = Array.from(parent.children).filter(function (c) { return c.tagName === current.tagName; });
        if (siblings.length > 1) {
          var idx = siblings.indexOf(current) + 1;
          parts.unshift(tag + classes + ":nth-child(" + idx + ")");
        } else {
          parts.unshift(tag + classes);
        }
      } else {
        parts.unshift(tag + classes);
      }
      current = parent;
    }
    return parts.join(" > ");
  }

  function captureElementContext() {
    var el = lastHoveredElement || document.elementFromPoint(lastCursorX, lastCursorY);
    if (!el) return null;

    var rect = el.getBoundingClientRect();
    return {
      selector: getCssSelector(el),
      tagName: el.tagName.toLowerCase(),
      text: (el.textContent || "").trim().slice(0, 200),
      outerHTML: el.outerHTML.slice(0, 500),
      attributes: {
        id: el.id || undefined,
        className: el.className && typeof el.className === "string" ? el.className : undefined,
        role: el.getAttribute("role") || undefined,
        ariaLabel: el.getAttribute("aria-label") || undefined,
        href: el.getAttribute("href") || undefined,
        type: el.getAttribute("type") || undefined,
        name: el.getAttribute("name") || undefined,
        placeholder: el.getAttribute("placeholder") || undefined,
      },
      boundingRect: {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        width: Math.round(rect.width),
        height: Math.round(rect.height),
      },
    };
  }

  // ─── Settings ──────────────────────────────────────────────

  async function getSettings() {
    return new Promise((resolve) => {
      chrome.storage.local.get(
        {
          serverUrl: window.location.origin,
          apiToken: "",
          testerName: "",
          projectSlug: "",
        },
        resolve
      );
    });
  }

  // ─── UI: Floating Button ───────────────────────────────────

  const btn = document.createElement("button");
  btn.className = "cc-feedback-btn";
  btn.textContent = "🎤";
  btn.title = "Gravar nota de voz";
  document.body.appendChild(btn);

  const toast = document.createElement("div");
  toast.className = "cc-feedback-toast";
  document.body.appendChild(toast);

  function showToast(message, isError) {
    toast.textContent = "";
    var label = document.createElement("div");
    label.className = "cc-feedback-toast-label";
    label.textContent = isError ? "Erro" : "Transcrito";
    var msg = document.createElement("div");
    msg.textContent = message;
    toast.appendChild(label);
    toast.appendChild(msg);
    toast.classList.toggle("cc-feedback-toast--error", !!isError);
    toast.classList.add("cc-feedback-toast--visible");
    setTimeout(function () { toast.classList.remove("cc-feedback-toast--visible"); }, 4000);
  }

  // ─── Recording ─────────────────────────────────────────────

  btn.addEventListener("click", async () => {
    if (isRecording) {
      stopRecording();
    } else {
      await startRecording();
    }
  });

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunks = [];
      mediaRecorder = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
          ? "audio/webm;codecs=opus"
          : "audio/webm",
      });

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunks.push(e.data);
      };

      mediaRecorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(audioChunks, { type: "audio/webm" });
        sendVoiceNote(blob);
      };

      mediaRecorder.start();
      isRecording = true;
      btn.classList.add("cc-feedback-btn--recording");
      btn.textContent = "⏹";
      btn.title = "Parar gravação";
    } catch (err) {
      showToast("Não foi possível aceder ao microfone: " + err.message, true);
    }
  }

  function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
      mediaRecorder.stop();
    }
    isRecording = false;
    btn.classList.remove("cc-feedback-btn--recording");
    btn.textContent = "🎤";
    btn.title = "Gravar nota de voz";
  }

  // ─── Send to API ───────────────────────────────────────────

  async function sendVoiceNote(audioBlob) {
    const settings = await getSettings();

    if (!settings.apiToken) {
      showToast("Configura o API Token no popup da extensão.", true);
      return;
    }
    if (!settings.projectSlug) {
      showToast("Configura o slug do projecto no popup.", true);
      return;
    }

    btn.textContent = "⏳";
    btn.title = "A enviar...";

    var elementContext = captureElementContext();

    const formData = new FormData();
    formData.append("audio", audioBlob, "voice-note.webm");
    formData.append("projectSlug", settings.projectSlug);
    formData.append("testerName", settings.testerName || "Tester");
    formData.append("pageUrl", window.location.href);
    formData.append("pageTitle", document.title);
    formData.append("timestampMs", String(Date.now()));
    formData.append("cursorX", String(Math.round(lastCursorX)));
    formData.append("cursorY", String(Math.round(lastCursorY)));
    if (elementContext) {
      formData.append("elementContext", JSON.stringify(elementContext));
    }
    if (currentSessionId) {
      formData.append("sessionId", currentSessionId);
    }

    try {
      const res = await fetch(`${settings.serverUrl}/api/feedback/voice-note`, {
        method: "POST",
        headers: { Authorization: `Bearer ${settings.apiToken}` },
        body: formData,
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: res.statusText }));
        showToast(err.error || `Erro ${res.status}`, true);
        btn.textContent = "🎤";
        btn.title = "Gravar nota de voz";
        return;
      }

      const result = await res.json();
      currentSessionId = result.sessionId;

      if (result.transcript) {
        showToast(result.transcript);
      } else {
        showToast("Nota enviada (sem transcrição).");
      }
    } catch (err) {
      showToast("Erro de rede: " + err.message, true);
    }

    btn.textContent = "🎤";
    btn.title = "Gravar nota de voz";
  }

  // ─── Finalize session on page unload ───────────────────────

  window.addEventListener("beforeunload", async () => {
    if (!currentSessionId) return;

    const settings = await getSettings();
    const body = JSON.stringify({
      endedAt: new Date().toISOString(),
      pagesVisited,
      status: "ready",
    });

    // sendBeacon doesn't support custom headers, so use fetch with keepalive
    try {
      fetch(`${settings.serverUrl}/api/feedback/sessions/${currentSessionId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${settings.apiToken}`,
        },
        body,
        keepalive: true,
      });
    } catch (_) {
      // Best-effort
    }
  });
})();
