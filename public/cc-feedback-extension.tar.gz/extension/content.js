// ─── Command Center Feedback — Content Script ──────────────
// Floating button + voice recording + DOM event capture.

(function () {
  "use strict";

  var mediaRecorder = null;
  var audioChunks = [];
  var isRecording = false;
  var currentSessionId = null;
  var pagesVisited = [window.location.href];

  // ─── Event Recording State ─────────────────────────────────

  var recordingStartTime = 0;
  var recordedEvents = [];
  var eventListeners = [];
  var mutationObserver = null;
  var inputDebounceTimers = {};

  function isOurElement(el) {
    return el && (el.closest(".cc-feedback-btn") || el.closest(".cc-feedback-toast"));
  }

  function relativeMs() {
    return Date.now() - recordingStartTime;
  }

  function getCssSelector(el) {
    if (!el || el === document.body || el === document.documentElement) return "body";
    var parts = [];
    var current = el;
    while (current && current !== document.body) {
      var tag = current.tagName.toLowerCase();
      if (current.id) {
        parts.unshift(tag + "#" + current.id);
        break;
      }
      var classes = current.className && typeof current.className === "string"
        ? "." + current.className.trim().split(/\s+/).slice(0, 3).join(".")
        : "";
      var parent = current.parentElement;
      if (parent) {
        var siblings = Array.from(parent.children).filter(function (c) { return c.tagName === current.tagName; });
        if (siblings.length > 1) {
          var idx = siblings.indexOf(current) + 1;
          parts.unshift(tag + classes + ":nth-child(" + idx + ")");
        } else {
          parts.unshift(tag + classes);
        }
      } else {
        parts.unshift(tag + classes);
      }
      current = parent;
    }
    return parts.join(" > ");
  }

  function startEventRecording() {
    recordingStartTime = Date.now();
    recordedEvents = [];
    inputDebounceTimers = {};

    function onClickCapture(e) {
      if (isOurElement(e.target)) return;
      var el = e.target;
      recordedEvents.push({
        type: "click",
        timestampMs: relativeMs(),
        selector: getCssSelector(el),
        tagName: el.tagName.toLowerCase(),
        text: (el.textContent || "").trim().slice(0, 100),
        outerHTML: el.outerHTML.slice(0, 300),
      });
    }

    function onInputCapture(e) {
      if (isOurElement(e.target)) return;
      var el = e.target;
      var key = getCssSelector(el);
      // Debounce: only record after 500ms of no typing
      if (inputDebounceTimers[key]) clearTimeout(inputDebounceTimers[key]);
      inputDebounceTimers[key] = setTimeout(function () {
        recordedEvents.push({
          type: "input",
          timestampMs: relativeMs(),
          selector: key,
          tagName: el.tagName.toLowerCase(),
          value: (el.value || "").slice(0, 200),
        });
      }, 500);
    }

    function onFocusCapture(e) {
      if (isOurElement(e.target)) return;
      var el = e.target;
      if (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable) {
        recordedEvents.push({
          type: "focus",
          timestampMs: relativeMs(),
          selector: getCssSelector(el),
          tagName: el.tagName.toLowerCase(),
        });
      }
    }

    function onNavigateCapture() {
      recordedEvents.push({
        type: "navigate",
        timestampMs: relativeMs(),
        pageUrl: window.location.href,
      });
    }

    // Register listeners (capture phase to catch everything)
    document.addEventListener("click", onClickCapture, true);
    document.addEventListener("input", onInputCapture, true);
    document.addEventListener("focus", onFocusCapture, true);
    window.addEventListener("popstate", onNavigateCapture);

    eventListeners = [
      { target: document, type: "click", fn: onClickCapture, capture: true },
      { target: document, type: "input", fn: onInputCapture, capture: true },
      { target: document, type: "focus", fn: onFocusCapture, capture: true },
      { target: window, type: "popstate", fn: onNavigateCapture, capture: false },
    ];

    // MutationObserver for modals
    mutationObserver = new MutationObserver(function (mutations) {
      for (var i = 0; i < mutations.length; i++) {
        var mutation = mutations[i];
        // Check for added dialog/modal elements
        for (var j = 0; j < mutation.addedNodes.length; j++) {
          var node = mutation.addedNodes[j];
          if (node.nodeType !== 1) continue;
          if (node.tagName === "DIALOG" || (node.getAttribute && node.getAttribute("role") === "dialog")) {
            recordedEvents.push({
              type: "modal_open",
              timestampMs: relativeMs(),
              selector: getCssSelector(node),
              text: (node.textContent || "").trim().slice(0, 100),
            });
          }
        }
        // Check for removed dialog/modal elements
        for (var k = 0; k < mutation.removedNodes.length; k++) {
          var removed = mutation.removedNodes[k];
          if (removed.nodeType !== 1) continue;
          if (removed.tagName === "DIALOG" || (removed.getAttribute && removed.getAttribute("role") === "dialog")) {
            recordedEvents.push({
              type: "modal_close",
              timestampMs: relativeMs(),
              selector: getCssSelector(removed),
            });
          }
        }
        // Check for dialog open attribute changes
        if (mutation.type === "attributes" && mutation.attributeName === "open" && mutation.target.tagName === "DIALOG") {
          var dlg = mutation.target;
          recordedEvents.push({
            type: dlg.hasAttribute("open") ? "modal_open" : "modal_close",
            timestampMs: relativeMs(),
            selector: getCssSelector(dlg),
            text: dlg.hasAttribute("open") ? (dlg.textContent || "").trim().slice(0, 100) : undefined,
          });
        }
      }
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["open"] });
  }

  function stopEventRecording() {
    // Remove all event listeners
    for (var i = 0; i < eventListeners.length; i++) {
      var l = eventListeners[i];
      l.target.removeEventListener(l.type, l.fn, l.capture);
    }
    eventListeners = [];

    // Clear debounce timers
    for (var key in inputDebounceTimers) {
      clearTimeout(inputDebounceTimers[key]);
    }
    inputDebounceTimers = {};

    // Disconnect mutation observer
    if (mutationObserver) {
      mutationObserver.disconnect();
      mutationObserver = null;
    }

    return recordedEvents;
  }

  // ─── Page Navigation Tracking ──────────────────────────────

  var origPushState = history.pushState;
  history.pushState = function () {
    origPushState.apply(this, arguments);
    onNavigate();
  };
  window.addEventListener("popstate", onNavigate);

  function onNavigate() {
    var url = window.location.href;
    if (!pagesVisited.includes(url)) {
      pagesVisited.push(url);
    }
  }

  // ─── Settings ──────────────────────────────────────────────

  function getSettings() {
    return new Promise(function (resolve) {
      chrome.storage.local.get(
        {
          serverUrl: window.location.origin,
          apiToken: "",
          testerName: "",
          projectSlug: "",
        },
        resolve
      );
    });
  }

  // ─── UI: Floating Button ───────────────────────────────────

  var btn = document.createElement("button");
  btn.className = "cc-feedback-btn";
  btn.textContent = "🎤";
  btn.title = "Gravar nota de voz";
  document.body.appendChild(btn);

  var toastEl = document.createElement("div");
  toastEl.className = "cc-feedback-toast";
  document.body.appendChild(toastEl);

  function showToast(message, isError) {
    toastEl.textContent = "";
    var label = document.createElement("div");
    label.className = "cc-feedback-toast-label";
    label.textContent = isError ? "Erro" : "Transcrito";
    var msg = document.createElement("div");
    msg.textContent = message;
    toastEl.appendChild(label);
    toastEl.appendChild(msg);
    toastEl.classList.toggle("cc-feedback-toast--error", !!isError);
    toastEl.classList.add("cc-feedback-toast--visible");
    setTimeout(function () { toastEl.classList.remove("cc-feedback-toast--visible"); }, 4000);
  }

  // ─── Recording ─────────────────────────────────────────────

  btn.addEventListener("click", function () {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  });

  function startRecording() {
    navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
      audioChunks = [];
      mediaRecorder = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
          ? "audio/webm;codecs=opus"
          : "audio/webm",
      });

      mediaRecorder.ondataavailable = function (e) {
        if (e.data.size > 0) audioChunks.push(e.data);
      };

      mediaRecorder.onstop = function () {
        stream.getTracks().forEach(function (t) { t.stop(); });
        var events = stopEventRecording();
        var blob = new Blob(audioChunks, { type: "audio/webm" });
        sendVoiceNote(blob, events);
      };

      mediaRecorder.start();
      startEventRecording();
      isRecording = true;
      btn.classList.add("cc-feedback-btn--recording");
      btn.textContent = "⏹";
      btn.title = "Parar gravação";
    }).catch(function (err) {
      showToast("Não foi possível aceder ao microfone: " + err.message, true);
    });
  }

  function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
      mediaRecorder.stop();
    }
    isRecording = false;
    btn.classList.remove("cc-feedback-btn--recording");
    btn.textContent = "🎤";
    btn.title = "Gravar nota de voz";
  }

  // ─── Send to API ───────────────────────────────────────────

  function sendVoiceNote(audioBlob, events) {
    getSettings().then(function (settings) {
      if (!settings.apiToken) {
        showToast("Configura o API Token no popup da extensão.", true);
        return;
      }
      if (!settings.projectSlug) {
        showToast("Configura o slug do projecto no popup.", true);
        return;
      }

      btn.textContent = "⏳";
      btn.title = "A enviar...";

      var formData = new FormData();
      formData.append("audio", audioBlob, "voice-note.webm");
      formData.append("projectSlug", settings.projectSlug);
      formData.append("testerName", settings.testerName || "Tester");
      formData.append("pageUrl", window.location.href);
      formData.append("pageTitle", document.title);
      formData.append("timestampMs", String(Date.now()));
      if (events && events.length > 0) {
        formData.append("events", JSON.stringify(events));
      }
      if (currentSessionId) {
        formData.append("sessionId", currentSessionId);
      }

      fetch(settings.serverUrl + "/api/feedback/voice-note", {
        method: "POST",
        headers: { Authorization: "Bearer " + settings.apiToken },
        body: formData,
      })
        .then(function (res) {
          if (!res.ok) {
            return res.json().catch(function () { return { error: res.statusText }; }).then(function (err) {
              showToast(err.error || "Erro " + res.status, true);
              throw new Error("stop");
            });
          }
          return res.json();
        })
        .then(function (result) {
          if (!result) return;
          currentSessionId = result.sessionId;
          if (result.transcript) {
            showToast(result.transcript);
          } else {
            showToast("Nota enviada (sem transcrição).");
          }
        })
        .catch(function (err) {
          if (err.message !== "stop") {
            showToast("Erro de rede: " + err.message, true);
          }
        })
        .finally(function () {
          btn.textContent = "🎤";
          btn.title = "Gravar nota de voz";
        });
    });
  }

  // ─── Finalize session on page unload ───────────────────────

  window.addEventListener("beforeunload", function () {
    if (!currentSessionId) return;

    getSettings().then(function (settings) {
      var body = JSON.stringify({
        endedAt: new Date().toISOString(),
        pagesVisited: pagesVisited,
        status: "ready",
      });

      try {
        fetch(settings.serverUrl + "/api/feedback/sessions/" + currentSessionId, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + settings.apiToken,
          },
          body: body,
          keepalive: true,
        });
      } catch (_) {
        // Best-effort
      }
    });
  });
})();
